ESedi
ElementSyntax editor

run:

cmd
python esedi.py


