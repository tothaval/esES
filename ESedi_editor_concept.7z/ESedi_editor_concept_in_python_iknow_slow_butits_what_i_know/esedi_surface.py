# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtCore import QSize, Qt, QUrl

from PyQt6.QtGui import QFont

from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QVBoxLayout,
    QWidget
    )

import asyncio, sys

import esedi_controls as ec, esedi_startup as es

from os_interaction_library import file_loader

from ui_library import (
    main_editor as me,
    menu_bar as mb
)

class ESediSurface(QMainWindow):
    def __init__(self, esedi):
        super().__init__()

        self.central_widget = esedi.get_qt_manager().q_frame()

        self.esedi = esedi

        self.config_main_window()

        self.menu_bar = mb.SimpleMenuBar(self)
        self.menu_bar.fill(ec.ESediControls(self.esedi).config_menu_bar())

        self.main_editor = me.MainEditor(self).get_widget()
        
        self.panel_widget = esedi.get_qt_manager().q_dock_widget("ElementPanel", self)    
        
        self.config_main_editor()
        self.config_panel_widget()        

        self.central_widget.setLayout(self.assemble())

        #self.esedi.add_size_grip(self.get_main_window())

        self.connect_signals()
        self.connect_panel_signals()


    def assemble(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        qt_manager = self.esedi.get_qt_manager()

        qt_object_list = [
            self.menu_bar.get_widget(),
            self.main_editor
        ]

        spacing = 2

        vertical_layout = qt_manager.qv_box_layout(qt_object_list, spacing)

        return vertical_layout

    def config_panel_widget(self):
    
        panel_buttons = mb.SimpleMenuBar(self)
        panel_buttons.fill(ec.ESediControls(self.esedi).config_panel_bar_t())
        panel_buttons.set_tool_tips(ec.ESediControls(self.esedi).config_panel_bar_tt())
        panel_buttons.set_spacing(1)
        panel_buttons.set_use_vertical_layout(True)
  
        #self.panel_widget.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea |
        #                            Qt.DockWidgetArea.RightDockWidgetArea)
        self.panel_widget.setWidget(panel_buttons.get_widget())
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.panel_widget);

    def config_main_window(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setObjectName("ESedi_MainWindow")

        self.setCentralWidget(self.central_widget)

        self.esedi.resize(1024, 768)

    def config_main_editor(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.main_editor.file_details.set_read_only(True)

    def connect_panel_signals(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        panel_buttons = self.panel_widget.widget().get_button_list()
        
        for button in panel_buttons:
            button.clicked.connect(self.panel_button_click)


  
    def connect_signals(self):    
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        exit_button = self.menu_bar.get_button_by_text("Exit")
        exit_button.clicked.connect(self.exit_click)

        load_file_button = self.menu_bar.get_button_by_text("Load File")
        load_file_button.clicked.connect(self.load_file_click)

        new_file_button = self.menu_bar.get_button_by_text("New File")
        new_file_button.clicked.connect(self.new_file_click)

        save_as_button = self.menu_bar.get_button_by_text("Save As")
        save_as_button.clicked.connect(self.save_as_click)

        save_button = self.menu_bar.get_button_by_text("Save")
        save_button.clicked.connect(self.save_click)

    def get_layout(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        layout = self.esedi.get_qt_manager().q_stacked_layout()

        layout.addWidget(self.get_main_window())

        return layout

    def get_main_window(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self

    def exit_click(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        sys.exit()

    def load_file_click(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.main_editor.disconnect_signals()

        logix = es.ESediStartup(self)

        self.main_editor.insert_document(asyncio.run(logix.load_action()))

        self.main_editor.top_of_document()

        self.main_editor.connect_signals()

    def new_file_click(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.main_editor.new_file()

    def save_as_click(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        logix = es.ESediStartup(self)

        asyncio.run(logix.save_as_action())

    def save_click(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        logix = es.ESediStartup(self)

        asyncio.run(logix.save_action())

    #panel_buttons
    def panel_button_click(self):
        button = self.sender()
    
        self.main_editor.get_editor().insertPlainText(button.toolTip())
