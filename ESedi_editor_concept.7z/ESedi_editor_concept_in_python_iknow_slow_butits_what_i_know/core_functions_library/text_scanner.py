# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
import os, os.path, sys

# setting path
sys.path.append('../esedi')

from PyQt6.QtCore import QRegularExpression, QSize, QStringListModel, Qt, QTimer, QUrl

from PyQt6.QtGui import (
    QBrush,
    QColor,
    QColorConstants,
    QFont,
    QSyntaxHighlighter,
    QTextCharFormat,
    QTextCursor,
    QTextDocument,
    QTextOption
)

from PyQt6.QtWidgets import (
    QTextBrowser
)

from os_interaction_library import file_saver


class TextScanner( QSyntaxHighlighter ):

    def __init__( self, parent ):
      QSyntaxHighlighter.__init__( self, parent )
      self.parent = parent
      keyword = QTextCharFormat()
      reservedClasses = QTextCharFormat()
      assignmentOperator = QTextCharFormat()
      delimiter = QTextCharFormat()
      specialConstant = QTextCharFormat()
      boolean = QTextCharFormat()
      number = QTextCharFormat()
      comment = QTextCharFormat()
      string = QTextCharFormat()
      singleQuotedString = QTextCharFormat()

      self.highlightingRules = []

      # keyword
      brush = QBrush( Qt.GlobalColor.darkBlue, Qt.BrushStyle.SolidPattern )
      keyword.setForeground( brush )
      keyword.setFontWeight( QFont.Weight.Bold )
      keywords = QStringListModel( [ "break", "else", "for", "if", "in",
                                "next", "repeat", "return", "switch",
                                "try", "while" ] )
      for word in keywords.stringList():
        pattern = QRegularExpression("\\b" + word + "\\b")
        rule = HighlightingRule( pattern, keyword )
        self.highlightingRules.append( rule )

      # reservedClasses
      reservedClasses.setForeground( brush )
      reservedClasses.setFontWeight( QFont.Weight.Bold )
      keywords = QStringListModel( [ "array", "character", "complex",
                                "data.frame", "double", "factor",
                                "function", "integer", "list",
                                "logical", "matrix", "numeric",
                                "vector" ] )
      for word in keywords.stringList():
        pattern = QRegularExpression("\\b" + word + "\\b")
        rule = HighlightingRule( pattern, reservedClasses )
        self.highlightingRules.append( rule )

      # assignmentOperator
      brush = QBrush( Qt.GlobalColor.yellow, Qt.BrushStyle.SolidPattern )
      pattern = QRegularExpression( "(<){1,2}-" )
      assignmentOperator.setForeground( brush )
      assignmentOperator.setFontWeight( QFont.Weight.Bold )
      rule = HighlightingRule( pattern, assignmentOperator )
      self.highlightingRules.append( rule )

      # delimiter
      pattern = QRegularExpression( "[\)\(]+|[\{\}]+|[][]+" )
      delimiter.setForeground( brush )
      delimiter.setFontWeight( QFont.Weight.Bold )
      rule = HighlightingRule( pattern, delimiter )
      self.highlightingRules.append( rule )

      # specialConstant
      brush = QBrush( Qt.GlobalColor.green, Qt.BrushStyle.SolidPattern )
      specialConstant.setForeground( brush )
      keywords = QStringListModel( [ "Inf", "NA", "NaN", "NULL" ] )
      for word in keywords.stringList():
        pattern = QRegularExpression("\\b" + word + "\\b")
        rule = HighlightingRule( pattern, specialConstant )
        self.highlightingRules.append( rule )

      # boolean
      boolean.setForeground( brush )
      keywords = QStringListModel( [ "TRUE", "FALSE" ] )
      for word in keywords.stringList():
        pattern = QRegularExpression("\\b" + word + "\\b")
        rule = HighlightingRule( pattern, boolean )
        self.highlightingRules.append( rule )

      # number
      pattern = QRegularExpression( "[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?" )
      #pattern.setMinimal( True )
      number.setForeground( brush )
      rule = HighlightingRule( pattern, number )
      self.highlightingRules.append( rule )

      # comment
      brush = QBrush( Qt.GlobalColor.blue, Qt.BrushStyle.SolidPattern )
      pattern = QRegularExpression( "#[^\n]*" )
      comment.setForeground( brush )
      rule = HighlightingRule( pattern, comment )
      self.highlightingRules.append( rule )

      # string
      brush = QBrush( Qt.GlobalColor.red, Qt.BrushStyle.SolidPattern )
      pattern = QRegularExpression( "\".*\"" )
      #pattern.setMinimal( True )
      string.setForeground( brush )
      rule = HighlightingRule( pattern, string )
      self.highlightingRules.append( rule )

      # singleQuotedString
      pattern = QRegularExpression( "\'.*\'" )
      #pattern.setMinimal( True )
      singleQuotedString.setForeground( brush )
      rule = HighlightingRule( pattern, singleQuotedString )
      self.highlightingRules.append( rule )

    def highlightBlock( self, text ):
      for rule in self.highlightingRules:
        expression = QRegularExpression( rule.pattern )
        index = expression.globalMatchView( text )
        while index.hasNext():
          length = expression.matchedLength()
          self.setFormat( index, length, rule.format )
          index = text.indexOf( expression, index + length )
      self.setCurrentBlockState( 0 )

class HighlightingRule():
  def __init__( self, pattern, format ):
    self.pattern = pattern
    self.format = format

#class TestApp( QMainWindow ):
#  def __init__(self):
#    QMainWindow.__init__(self)
#    font = QFont()
#    font.setFamily( "Courier" )
#    font.setFixedPitch( True )
#    font.setPointSize( 10 )
#    editor = QTextEdit()
#    editor.setFont( font )
#    highlighter = MyHighlighter( editor, "Classic" )
#    self.setCentralWidget( editor )
#    self.setWindowTitle( "Syntax Highlighter" )
