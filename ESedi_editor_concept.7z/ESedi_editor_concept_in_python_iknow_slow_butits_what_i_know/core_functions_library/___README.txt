ESedi
ElementSyntax editor _ core functions library

collection of python files for esedi, offering core functions like
text analysis, syntax highlighting etc.


run:

cmd


