# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
import os, os.path, sys

# setting path
sys.path.append('../esedi')

from PyQt6.QtCore import QRegularExpression, QSize, Qt, QTimer, QUrl

from PyQt6.QtGui import (
    QColor,
    QFont,
    QSyntaxHighlighter,
    QTextCharFormat,
    QTextCursor,
    QTextDocument,
    QTextOption
)

from PyQt6.QtWidgets import (
    QTextBrowser
)

from os_interaction_library import file_saver

class SyntaxDefinition_ES(QSyntaxHighlighter):
    """
        class DataOutput provides a way to update the
        textbrowser elements of the plugin

        mittels self.document() kann das QTextDocument bearbeitet werden
    """

    def __init__(self, textbrowser):
        super().__init__()


    def detect_dynastic_elements(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        document = self.textbrowser.document()
        find_cursor = QTextCursor(document.begin())

        keywords = "??"
        color = "lightsteelblue"

        while True:

            find_pattern = QRegularExpression()
            find_pattern.setPattern("(([?]{1}[!]{1}.*)|([(]\+?[\S]*[)]))")


            find_cursor = document.find(find_pattern, find_cursor)
            if not find_cursor.isNull():

                char_format = QTextCharFormat()
                char_format.setTextOutline(QColor(color))

                find_cursor.mergeCharFormat(char_format)
                #search_cursor.mergeCharFormat(char_format)

                #find_cursor.insertText(found_text, char_format)

                #else:
                #    break

            else:
                break
                
