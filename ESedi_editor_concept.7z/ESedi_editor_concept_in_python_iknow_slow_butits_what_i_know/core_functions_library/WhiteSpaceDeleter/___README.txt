ESedi
ElementSyntax editor _ core functions library _ WhiteSpaceDeleter

class WhiteSpaceDeleter scans a document for trailing whitespaces,
carriage returns, line feeds and horizontal tabs, removes all whitespaces,
calculates the result and prints everything to the console


run:

python wsd.py -f "FILENAME"

