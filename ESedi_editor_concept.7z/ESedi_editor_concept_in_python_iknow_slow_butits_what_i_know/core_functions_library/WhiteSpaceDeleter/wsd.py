# -*- coding: utf-8 -*-

"""
WhiteSpaceDeleter

v: 0.0

Created:
			+ 2023-05-07 @author: Stephan Kammel
            + 2023-06-13 @author: Stephan Kammel

p:			tool for the deletion of trailing whitespaces
			in textfiles, f.e. python source code files,
			to solve f.e. pylint errors

Q & T (Questions and Thoughts):
<   GUI or CLI ?

>   CLI for Techproof, GUI for FullerProduct with statistics and stuff

-??? sollte erlauben, jede datei im directory zu bearbeiten


            löscht bisher Leerzeichen und Tabulatoren,
            zählt Tabulatoren aktuell als gelöschte Whitespaces
"""

import argparse, asyncio, os, pathlib

class WhiteSpaceDeleter:
    def __init__(self, arguments):
        (self.directory, self.file) = arguments

        self.ws_deleted_count = 0

        current_directory = self.get_cwdpath()

        if self.directory != "-":
            file = os.path.join(self.directory, self.file)

        if self.file != "-":
            Content = self.read_file(self.file)

            self.delete_file(self.file)

            self.save_file(self.file, Content)

        self.wsd_has_finished_txt = (
            f"current directory\n\t{current_directory}\n"
            + f"specified directory\n\t{self.directory}\n"
            + f"specified file\n\t{self.file}\n"
        )

        print(self.get_wsd_has_finished_txt())

    def delete_file(self, file_name):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        file = pathlib.Path(file_name)
        file.unlink()

    def get_cwdpath(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        return pathlib.Path.cwd()

    def get_work_done(self):
        return (
            self.get_wsd_has_finished_txt()
            + "\n\n"
            + f"{self.get_ws_deleted_count()}"
        )

    def get_ws_deleted_count(self):
        return self.ws_deleted_count

    def get_wsd_has_finished_txt(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        return self.wsd_has_finished_txt

    def separate_stupid_method(self, line):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_

        """
        del_count = []
        line_end = len(line) - 1

        for i in range(line_end, -1, -1):
        # https://en.wikipedia.org/wiki/List_of_Unicode_characters

            k = ord(line[i])

            if k in (10, 32):
                del_count.append(i)

            elif k == 9:
                del_count.append(i)

            else:
                break

        trailing_space = 0

        if len(del_count) > 0:
            trailing_space = min(del_count)

        reduced_whitespaces = len(line) - trailing_space

        reduced_line = line[0: trailing_space]

        return reduced_line, reduced_whitespaces

    def read_file(self, file_name):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        Content = []

        Product = []

        with open(file_name) as f:

            Content = f.readlines()

        count = 0
        line_count = 1
        new_line = ""

        for line in Content:

            reduced_line, reduced_whitespaces = self.separate_stupid_method(line)

            line_start = f"{line_count}: "

            if reduced_whitespaces != 1:
                new_line  = f"{line_start} {reduced_whitespaces-1} {reduced_line}+"
                count += reduced_whitespaces-1
            else:
                new_line  = f"{line_start} - {reduced_line}+"

            line_count += 1

            Product.append(reduced_line)

            print(f"{new_line}")

        self.set_ws_deleted_count(count)

        print(f"\ntotal deleted whitespaces: {self.get_ws_deleted_count()}")
        


        return Product

    def save_file(self, file_name, Content):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        with open(file_name, 'w') as f:
            for line in Content:
                f.write(f"{line}\n")

    def set_ws_deleted_count(self, count):
        self.ws_deleted_count = count

if __name__ == "__main__":
    """_summary_

    Args:
        text (_type_): _description_

    Returns:
        _type_: _description_
    """

    parser = argparse.ArgumentParser()

    parser.add_argument("-d", "--directory", dest="directory", default="-",
                        type=str, help="specify a folder for processing")

    parser.add_argument("-f", "--file", dest="file", default="-",
                        type=str, help="specify a file for processing")

    args = parser.parse_args()





