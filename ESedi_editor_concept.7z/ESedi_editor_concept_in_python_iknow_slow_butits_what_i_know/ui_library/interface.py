# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtCore import Qt

from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDateTimeEdit,
    QDial,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFontComboBox,
    QFrame,
    QGraphicsScene,
    QGraphicsView,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLCDNumber,
    QLineEdit,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizeGrip,
    QSlider,
    QSplitter,
    QSpinBox,
    QStackedLayout,
    QTextBrowser,
    QTextEdit,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
)


class QT_Distributor:
    """
        class QT_Distributor provides qt objects
    """

    def qh_box_layout(self, qt_object_list, spacing):
        """_summary_

        Args:
            qt_object_list (list): composition of qwidgets or qlayouts to be added
                to a qhboxlayout

            spacing (int): space between objects

        Returns:
            _type_: _description_
        """
        layout = QHBoxLayout()

        layout.setSpacing(spacing)

        for o in qt_object_list:
            if issubclass(type(o), QWidget):
                layout.addWidget(o)
            elif issubclass(type(o), QLayout):
                layout.addLayout(o)

        return layout

    def qv_box_layout(self, qt_object_list, spacing):
        """_summary_

        Args:
            qt_object_list (list): composition of qwidgets or qlayouts to be added
                to a qvboxlayout

            spacing (int): space between objects

        Returns:
            _type_: _description_
        """
        layout = QVBoxLayout()

        layout.setSpacing(spacing)

        for o in qt_object_list:
            if issubclass(type(o), QWidget):
                layout.addWidget(o)
            elif issubclass(type(o), QLayout):
                layout.addLayout(o)

        return layout

    def q_dock_widget(self, title, main_window):
        dock_widget = QDockWidget(title, main_window)
    
        return dock_widget

    def q_frame(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        frame = QFrame()

        return frame

    def q_file_dialog(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        file_dialog = QFileDialog()

        return file_dialog

    def q_graphics_scene(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        scene = QGraphicsScene()

        return scene

    def q_grid_layout(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        layout = QGridLayout()

        return layout

    def q_main_window(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        main_window = QMainWindow()

        return main_window

    def q_pushbutton(self, text):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        button = QPushButton(text)

        return button

    def q_stacked_layout(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        layout = QStackedLayout()

        return layout

    def q_size_grip(self, widget):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        size_grip = QSizeGrip(widget)

        return size_grip

    def q_splitter(self, vertical = False):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        orientation = Qt.Orientation.Horizontal

        if vertical:
            orientation = Qt.Orientation.Vertical

        splitter = QSplitter(orientation)

        return splitter

    def q_textbrowser(self, text = ""):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        textbrowser = QTextBrowser()
        textbrowser.setText(text)

        return textbrowser

    def q_widget(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return QWidget()
