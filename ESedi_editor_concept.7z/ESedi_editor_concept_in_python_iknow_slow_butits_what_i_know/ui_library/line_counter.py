# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""

from PyQt6.QtCore import Qt

from PyQt6.QtWidgets import (
    QLabel,
    QScrollArea
)

class LineCount(QScrollArea):
    """
        class DataOutput provides a way to update the
        textbrowser elements of the plugin
    """

    def __init__(self):
        super().__init__()

        self.label = QLabel()

    def assemble(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.label = QLabel()

        self.label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.label.setContentsMargins(0, 4, 0, 0)
        self.label.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.setWidget(self.label)

    def clear(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.label.clear()

    def get_widget(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.assemble()

        return self

    def set_text(self, text: str):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        #self.clear()

        self.label.setText(text)
