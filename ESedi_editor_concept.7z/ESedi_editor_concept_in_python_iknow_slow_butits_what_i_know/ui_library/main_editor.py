# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
import os, os.path, sys

# setting path
sys.path.append('../esedi')

from PyQt6.QtCore import QSize, Qt, QUrl

from PyQt6.QtGui import QFont, QTextDocument, QTextOption

from PyQt6.QtWidgets import (
    QFrame,
    QTextBrowser
)

from . import io, line_counter as lc

#from . import interface, browser as bws

from core_functions_library import text_scanner as text_sc

from os_interaction_library import file_saver

class MainEditor(QFrame):
    """
        class DataOutput provides a way to update the
        textbrowser elements of the plugin
    
        mittels self.document() kann das QTextDocument bearbeitet werden
    """

    def __init__(self, esedi_surface):
        super().__init__()
    
        # interface creation
        self.esedi_surface = esedi_surface
        self.esedi = esedi_surface.esedi
        self.qt_manager = self.esedi.get_qt_manager()
    
        self.file_path = ""
    
        self.font = QFont("Calibri", 12)
    
        self.editor = io.IO_Browser()
        self.config_editor()
    
        self.file_details = io.IO_Browser()
    
        self.line_count = lc.LineCount().get_widget()        
    
        self.editor.document().setDefaultFont(self.font)
    
        self.text_scanner = text_sc.TextScanner(self.get_editor())
    
        self.connect_signals()


    #methods

    def add_line(self, line: str):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.text += line

        self.setText(self.text)

    def clear_text(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.clear()
        self.text = ""

    def config_editor(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.editor.set_read_only(True)
        self.editor.setOpenLinks(True)
        self.editor.setReadOnly(False)
        self.editor.setWordWrapMode(QTextOption.WrapMode.NoWrap)
        self.editor.setUndoRedoEnabled(True)

    def connect_signals(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.editor.textChanged.connect(self.text_change)

        self.editor.verticalScrollBar().valueChanged.connect(self.slider_change)

    def disconnect_signals(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.editor.textChanged.disconnect(self.text_change)

        self.editor.verticalScrollBar().valueChanged.disconnect(self.slider_change)
        
        self.text_scanner = text_sc.TextScanner(self.get_editor())

    def get_document(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.editor.document()

    def get_editor(self):
        return self.editor

    def get_file_details(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.file_details

    def get_file_path(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.file_path

    def get_widget(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        vertical_splitter = self.qt_manager.q_splitter(True)
        horizontal_splitter = self.qt_manager.q_splitter()

        horizontal_splitter.addWidget(self.line_count)
        horizontal_splitter.addWidget(self.editor)

        horizontal_splitter.setStretchFactor(0, 1)
        horizontal_splitter.setStretchFactor(1, 6)

        vertical_splitter.addWidget(horizontal_splitter)
        vertical_splitter.addWidget(self.file_details)

        vertical_splitter.setStretchFactor(0, 6)
        vertical_splitter.setStretchFactor(1, 1)

        layout = self.qt_manager.q_grid_layout()

        layout.addWidget(vertical_splitter)

        self.setLayout(layout)

        return self

    def get_h_scrollbar_position(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.horizontalScrollBar().value()

    def get_v_scrollbar_position(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.verticalScrollBar().value()

    def get_text(self) -> bool:
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.text()

    def insert_document(self, document):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        (name, content) = document

        self.set_file_path(name)
        self.set_text(content)

        self.file_details.setText(name)
        
        self.text_scanner = text_sc.TextScanner(self.editor)
        self.text_scanner.scan()

    def new_file(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_

            später wenn ordnerpfade konfiguriert werden können,
            sollte die neue datei im entsprechenden ordner bei klick auf
            save gespeichert werden, aktuell speichter es diese im ordner
            von esedi

        """

        self.set_file_path("new_file.txt")

        self.file_details.setText(self.get_file_path())

        self.editor.new_document()

    def set_file_details_text(self, text: str):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        if isinstance(text, str):
            self.file_details.setText(self.file_path + "\n\n" + text)

    def set_file_path(self, path):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.file_path = path

    def set_read_only(self, read_only: bool):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setReadOnly(read_only)

    def set_text(self, text: str):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        if isinstance(text, str):
            self.editor.setText(text)

    def set_tooltip(self, text):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setToolTip(text)

    def slider_change(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        slider = self.sender()

        #self.document().findBlockByLineNumber(slider.value())

        self.line_count.verticalScrollBar().setValue(slider.value())

        self.update_line_count()

    def style(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        pass
        #self.line_count.setStyleSheet(
        #     "QFrame { " +
        #        f"border: 3px solid steelblue; border-radius: 9px;" +
        #        "}"       +
        #

        #)
        #
        #self.setStyleSheet(
        #    "QTextBrowser { " +
        #        "background: rgba(255,255,255,255);" +
        #        f"border: 3px solid steelblue;" +
        #        "border-radius: 9px;" +
        #        "}"
        #)

    def text_change(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.update_line_count()
        
        #self.disconnect_signals()
        #
        ##self.text_scanner.detect_namespace()
        ##self.text_scanner.__init__(self.get_document(), "([:]([\S]*))")
        #
        #self.connect_signals()

    def top_of_document(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.editor.verticalScrollBar().setValue(0)

        self.update_line_count()

    def update_line_count(self, lines = 0):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        text_II = ""

        for i in range(0, self.editor.document().lineCount()):

            text_II += f"{i}\n"

        self.line_count.set_text(text_II)

        #self.setToolTip(str(lines) + "\n" +  text_II)
