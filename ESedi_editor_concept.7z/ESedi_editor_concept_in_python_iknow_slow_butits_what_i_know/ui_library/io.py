# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtGui import QTextDocument, QTextOption

from PyQt6.QtWidgets import (
    QTextBrowser
)


class IO_Browser(QTextBrowser):
    """
        class DataOutput provides a way to update the
        textbrowser elements of the plugin
    """

    def __init__(self):
        super().__init__()

        self.setOpenLinks(True)
        self.setReadOnly(True)

        self.setWordWrapMode(QTextOption.WrapMode.NoWrap)
        self.setUndoRedoEnabled(True)

    def new_document(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setDocument(QTextDocument())

    def set_read_only(self, read_only: bool):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

