# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtWidgets import (
    QFrame
)

from . import interface

class SimpleMenuBar(QFrame):
    """
        class DataOutput provides a way to update the
        textbrowser elements of the plugin
    """

    def __init__(self, esedi_surface):
        super().__init__()

        self.esedi_surface = esedi_surface
        self.esedi = esedi_surface.esedi

        self.spacing = 5
        self.use_vertical_layout = False
        self.button_list = []


        # interface creation
        self.qt_manager = self.esedi.get_qt_manager()

    #methods
    def assemble(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        qt_manager = self.qt_manager

        qt_object_list = self.button_list

        spacing = self.spacing

        layout = qt_manager.qh_box_layout(qt_object_list, spacing)

        if self.use_vertical_layout:
            layout = qt_manager.qv_box_layout(qt_object_list, spacing)

        return layout

    def add__item(self, text):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        button = self.qt_manager.q_pushbutton(text)

        self.button_list.append(button)

    def enable_button_by_index(self, index):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        if len(self.button_list) > 0:
            self.button_list[index].setEnabled(enable)

    def enable_button_by_text(self, enable: bool):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        if len(self.button_list) > 0:
            for button in self.button_list:
                if button.text() == text:
                    button.setEnabled(enable)

    def fill(self, text_list: list):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        for text in text_list:
            self.add__item(text)

    def get_button_by_index(self, index):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        if len(self.button_list) > 0:
            return self.button_list[index]

        return None

    def get_button_by_text(self, text):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        if len(self.button_list) > 0:
            for button in self.button_list:
                if button.text() == text:
                    return button

        return None

    def get_button_count(self) -> int:
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return len(self.button_list)

    def get_button_list(self) -> int:
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.button_list

    def get_spacing(self) -> int:
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.spacing

    def get_use_vertical_layout(self) -> bool:
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.use_vertical_layout

    def get_widget(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setLayout(self.assemble())

        return self

    def set_spacing(self, spacing: int):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.spacing = spacing

    def set_tool_tips(self, tool_tips):
        
        if len(self.button_list) == len(tool_tips):
            for i in range(0, len(self.button_list)):                
                self.button_list[i].setToolTip(tool_tips[i])

    def set_use_vertical_layout(self, vertical: bool):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.use_vertical_layout = vertical

