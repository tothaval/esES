# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

""" #https://doc.qt.io/qt-6/stylesheet-syntax.html

class ESediStyle:
    def __init__(self, esedi):
        self.esedi = esedi

    def general_style_QAstractScrollArea(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QAstractScrollArea { " +
                #f"padding: 4px;" +
                f"border-radius: 17px;" +
            "}"
        )

        #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qabstractscrollarea

        return style

    def general_style_QFrame(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QFrame {background-color: rgba(120,120,120,30);" +
            "margin: 0px;" +
            "border-radius: 17px;" +
            "border: 0px solid blue;}"
        )

        #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qframe

        return style

    def general_style_QLabel(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QLabel { " +
                "background-color: rgba(255,255,255,255);" +
                f"font-family: {self.esedi.font.family()}; " +
                f"font-size: {self.esedi.font.pointSize()}pt;" +
                f"border: 1px solid darkslategrey;" +
                "border-radius: 17px;" +
                "text-align: right" +
                "}" +
            "QLabel:hover { " +
                "background-color: rgba(255,255,200,255);" +
                f"font-family: {self.esedi.font.family()}; " +
                f"font-size: {self.esedi.font.pointSize()}pt;" +
                #f"border: 1px solid yellowgreen;" +
                "}"
        )

        return style



    def general_style_QMainWindow(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QMainWindow#ESedi_MainWindow {background-color: rgba(120,120,120,30);" +
            #"margin: 10px;" +
            "padding: 10px;" +
            "border-radius: 17px;" +
            "border: 2px solid black;}"
        )

        #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qframe

        return style

    #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qmainwindow


    def general_style_QPushButton(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QPushButton { " +
            "background-color: rgba(255,255,255,255);" +
            f"font-family: {self.esedi.font.family()}; " +
            f"font-size: {self.esedi.font.pointSize()}pt;" +
            f"border: 3px solid goldenrod;" +
            f"border-radius: 9px;" +
            "}" +
            "QPushButton:hover { " +
            "background-color: rgba(133,255,255,133);"
            f"font-family: {self.esedi.font.family()}; " +
            f"font-size: {self.esedi.font.pointSize()}pt;" +
            f"border: 3px solid goldenrod;" +
            f"border-radius: 9px;" +
            "}"
        )

        #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qpushbutton

        return style

    def general_style_QScrollArea(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QScrollArea { " +
            #f"padding: 4px;" +
            f"border-radius: 17px;" +
            "}"
        )

        return style

    def general_style_QScrollBar(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QScrollBar { " +
            f"padding: 4px;" +
            f"border-radius: 17px;" +
            "border: 2px solid grey;" +
            "background: #32CC99;" +
            #"height: 15px;" +
            #"width: 15px;" +
            #"margin: 0px 20px 0 20px;" +
            "}" +
            "QScrollBar::handle:horizontal {       "   +
                "background: white;                "   +
                "min-width: 20px;                  "   +
            "}                                     "   +
            "QScrollBar::add-line:horizontal {     "   +
                "border: 2px solid grey;           "   +
                "background: #32CC99;              "   +
                "width: 20px;                      "   +
                "subcontrol-position: right;       "   +
                "subcontrol-origin: margin;        "   +
            "}                                     "   +
            "                                      "   +
            "QScrollBar::sub-line:horizontal {     "   +
                "border: 2px solid grey;           "   +
                "background: #32CC99;              "   +
                "width: 20px;                      "   +
                "subcontrol-position: left;        "   +
                "subcontrol-origin: margin;        "   +
            "}            " +
            "QScrollBar::handle:vertical {       "   +
                "background: white;                "   +
                "min-height 20px;                  "   +
            "}                                     "   +
            "QScrollBar::add-line:vertical {     "   +
                "border: 2px solid grey;           "   +
                "background: #32CC99;              "   +
                "height: 20px;                      "   +
                "subcontrol-position: bottom;       "   +
                "subcontrol-origin: margin;        "   +
            "}                                     "   +
            "                                      "   +
            "QScrollBar::sub-line:vertical {     "   +
                "border: 2px solid grey;           "   +
                "background: #32CC99;              "   +
                "height: 20px;                      "   +
                "subcontrol-position: top;        "   +
                "subcontrol-origin: margin;        "   +
            "}"
        )

        #https://doc.qt.io/qt-6/stylesheet-examples.html#customizing-qscrollbar

        return style

    def general_style_QSlider(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QSlider:groove:horizontal { " +
            f"padding: 4px;" +
            f"border-radius: 17px;" +
            "}"
        )

        #QSlider::groove:horizontal {
        #    border: 1px solid #999999;
        #    height: 8px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */
        #    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #B1B1B1, stop:1 #c4c4c4);
        #    margin: 2px 0;
        #}
        #
        #QSlider::handle:horizontal {
        #    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);
        #    border: 1px solid #5c5c5c;
        #    width: 18px;
        #    margin: -2px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */
        #    border-radius: 3px;
        #}

        #QSlider::groove:vertical {
            #background: red;
            #position: absolute; /* absolutely position 4px from the left and right of the widget. setting margins on the widget should work too... */
            #left: 4px; right: 4px;
        #}
        #
        #QSlider::handle:vertical {
            #height: 10px;
            #background: green;
            #margin: 0 -4px; /* expand outside the groove */
        #}
        #
        #QSlider::add-page:vertical {
            #background: white;
        #}
        #
        #QSlider::sub-page:vertical {
            #background: pink;
        #}


        return style

    def general_style_QSplitter(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            ".QSplitter { " +
            "background-color: rgba(255,255,255,155);" +
            f"border: 2px solid steelblue;" +
            f"border-radius: 17px;" +
            f"margin: 12px;" +
            "}" +
            ".QSplitter:handle { " +
            "background-color: rgba(133,133,133,155);" +
            f"border: 5px solid steelblue;" +
            f"border-radius: 17px;" +
            "height: 7px;" +
            "}"
        )

        return style

    def general_style_QTextBrowser(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            "QTextBrowser { " +
                "background-color: rgba(255,255,255,255);" +
                f"font-family: {self.esedi.font.family()}; " +
                f"font-size: {self.esedi.font.pointSize()}pt;" +
                f"border: 1px solid darkslategrey;" +
                f"border-radius: 17px;" +
                "}"
        )

        return style

    def general_style_QWidget(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        style = (
            ".QWidget {" +
            "background-color: rgba(210,210,210,0);" +
            "border: 2px solid black; border-radius: 17px;" +
            "}" +
            ".QWidget#ESedi_widget {" +
            "background-color: rgba(210,210,210,60);" +
            "border: 5px solid black; border-radius: 17px;" +
            "}"
            "QWidget#ESedi_Central {" +
            #"background-color: rgba(210,210,210,60);" +
            #"border: 5px solid black; border-radius: 17px;" +
            "padding: 10px;" +
            "}"
        )

        return style
