# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
import asyncio, os, os.path, sys

# setting path
sys.path.append('../esedi')


#import core_functions_library.white_space_deleter as wsd

from os_interaction_library import file_loader, file_saver

class ESediStartup:
    def __init__(self, esedi_surface):
        super().__init__()

        self.esedi_surface = esedi_surface
        self.esedi = esedi_surface.esedi

    async def load_action(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        file = file_loader.FileLoader()
    
        file.load(self.esedi_surface.get_main_window())
    
        await asyncio.sleep(1e-3)

        #self.textChanged.disconnect(self.text_change)
    
        name = file.get_file_name()
    
        content = file.get_file_content()

        #self.textChanged.connect(self.text_change)

        return (name, content)


    async def save_as_action(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        file_saver.FileSaver(self.esedi_surface.main_editor).save_as()
        
        await asyncio.sleep(1e-3)
    
    async def save_action(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
    
        file_saver.FileSaver(self.esedi_surface.main_editor).save()
        
        await asyncio.sleep(1e-3)
