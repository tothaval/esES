# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""

class ESediControls:
    def __init__(self, esedi):
        self.esedi = esedi

    def config_menu_bar(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        menu_items = [
            "New File",
            "Load File",
            "Save",
            "Save As",
            "Exit"
        ]

        return menu_items

    def config_panel_bar_t(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        menu_items = [        
            "!",
            "?",
            "??",
            "?!",
            ":",
            ";",
            ".",       
            "{}",
            "()",
            "[]",
            "!> <!",
            ":> <:",
            ";> <;",
            ".> <.",    
            "=!",
            "=?",
            "§",            
            "$",
            "<# #>"          
        ]

        return menu_items

    def config_panel_bar_tt(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        menu_items = [        
            self.definitions_program(),
            "?Namespace\n",
            "??Library\n",
            "?!Modifier\n",
            self.definitions_class(),
            self.definitions_method(),
            self.definitions_lambda(),
            "{}",
            "()",
            "[]",
            "!> <!",
            ":> <:",
            ";> <;",
            ".> <.",    
            self.definitions_if_else(),
            self.definitions_if(),
            self.definitions_loop(),
            self.definitions_pool(),
            "<# #>"           
        ]

        return menu_items

    def definitions_class(self):
        _rank = (
            ":Class\n" +
            ":>\n" +
            "()\n" +
            "{}\n" +
            "<:\n" +
            "\n\n" +
            "?!Modifier\n" +
            ":\n" +
            "\n\n"
        )
        
        return _rank

    def definitions_lambda(self):
        _rank = (
            ".\n" +
            ".>\n" +
            "()\n" +
            "{}\n" +
            "<.\n" +
            "\n\\n" +
            "?!Modifier\n" +
            ".\n" +
            "\n\n"
        )
        
        return _rank

    def definitions_method(self):
        _rank = (
            ";Method\n" +
            ";>\n" +
            "()\n" +
            "{}\n" +
            "<;\n" +
            "\n\n" +
            "?!Modifier\n" +
            ";\n" +
            "\n\n"
        )
        
        return _rank

    def definitions_program(self):
        _rank = (
            "!Program\n" +
            "!>\n" +
            "()\n" +
            "{}\n" +
            "<!\n" +
            "\n\n" +
            "?!Modifier\n" +
            "!\n" +
            "\n\n"
        )
        
        return _rank

    def definitions_if_else(self):
        _es = (
            "=!(){}.  ."
        )            
            
        return _es
    
    def definitions_if(self):
        _es = (
            "=?(){}.  ."
        ) 
                
        return _es
    
    def definitions_loop(self):
        _es = (
            "§(){}.  ."
        ) 
                
        return _es
    
    def definitions_pool(self):
        _es = (
            "$(){}.  ."
        ) 
        
        return _es
