ESedi
ElementSyntax editor _ os interaction library

a collection of python files for saving and loading of files,
as well as other os related interactions


run:

cmd


