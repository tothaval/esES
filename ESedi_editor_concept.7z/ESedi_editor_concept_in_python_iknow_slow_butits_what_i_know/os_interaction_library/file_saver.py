# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtWidgets import QMainWindow, QApplication, QPushButton, QFileDialog
from PyQt6.QtCore import pyqtSlot

import sys

# setting path
sys.path.append('../esedi')

# importing

from core_functions_library.WhiteSpaceDeleter import wsd

from ui_library import interface


class FileSaver:
    def __init__(self, parent):

        self.qt_manager = interface.QT_Distributor()

        self.parent = parent

    def save_as(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        name = QFileDialog.getSaveFileName(self.parent, 'Save File')[0]

        if name:
            self.write_and_clean(name)

        if not name:
            return

    def save(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        name = self.parent.get_file_path()

        if name:
            self.write_and_clean(name)

        if not name:
            return

    def write_and_clean(self, name):
        with open(name, 'w') as f:
            f.write(self.parent.get_document().toPlainText())

        wsd_arguments = ("-", self.parent.get_file_path())

        run = wsd.WhiteSpaceDeleter(wsd_arguments)
        
        self.parent.set_file_details_text(run.get_work_done())
