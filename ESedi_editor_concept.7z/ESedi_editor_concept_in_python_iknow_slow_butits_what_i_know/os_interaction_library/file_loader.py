# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtWidgets import QMainWindow, QApplication, QPushButton, QFileDialog
from PyQt6.QtCore import pyqtSlot
import sys


class FileLoader:
    def __init__(self):

        self.file_content = []

        self.file_name = ""

    def get_file_name(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.file_name

    def get_file_content(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.file_content

    def load(self, q_widget_based_object):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.file_content.clear()

        self.open_file_dialog(q_widget_based_object)

    def open_file_dialog(self, q_widget_based_object):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        (self.file_name, selected_filter) = QFileDialog.getOpenFileName(
            q_widget_based_object,
            "Open File",
            "${HOME}",
            "All Files (*);; Python Files (*.py);; PNG Files (*.png)",
        )

        if self.file_name:
            self.read_content()

        if not self.file_name:
            return

    def read_content(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        with open(self.file_name) as f:
            self.file_content = f.read()
