# -*- coding: utf-8 -*-

"""
ES Editor

v: 0.0

Created:
            + 2023-06-13 @author: Stephan Kammel

p:			tool for editing of text files,
			f.e. source code files,

Q & T (Questions and Thoughts):

"""
from PyQt6.QtCore import Qt, QPointF

from PyQt6.QtGui import QFont

from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QSizeGrip,
    QWidget
    )

import sys

import esedi_style as style, esedi_surface as surface

from ui_library import (
    interface
)


class ESedi(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("ESedi_widget")

        self.dragPos = QPointF()

        self.qt_manager = interface.QT_Distributor()

        self.font = QFont("Calibri", 12)

        self.gui = surface.ESediSurface(self)

        self.style(style.ESediStyle(self))

        self.window_attributes_and_flags()

        self.setLayout(self.gui.get_layout())

    def center(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        qr = self.frameGeometry()
        cp = self.screen().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def mousePressEvent(self, event):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.dragPos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.move(self.pos() + event.globalPosition().toPoint() - self.dragPos )
        self.dragPos = event.globalPosition().toPoint()
        event.accept()

    def get_font(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.font

    def get_gui(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.gui

    def get_logix(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.logix

    def get_qt_manager(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.qt_manager

    def window_attributes_and_flags(self):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint)

    def style(self, style):
        """_summary_

        Args:
            text (_type_): _description_

        Returns:
            _type_: _description_
        """

        self.setStyleSheet(
            style.general_style_QAstractScrollArea() +
            style.general_style_QFrame() +
            style.general_style_QLabel() +
            style.general_style_QMainWindow() +
            style.general_style_QPushButton() +
            style.general_style_QScrollArea() +
            style.general_style_QScrollBar() +
            style.general_style_QSplitter() +
            style.general_style_QTextBrowser() +
            style.general_style_QWidget()
        )

if __name__ == "__main__":
    App = QApplication(sys.argv)
    window = ESedi()
    window.show()

    sys.exit(App.exec())
